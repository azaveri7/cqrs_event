package com.techbank.cqrscore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CqrsCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
