package com.techbank.accountcmd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountCmdApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountCmdApplication.class, args);
	}

}
