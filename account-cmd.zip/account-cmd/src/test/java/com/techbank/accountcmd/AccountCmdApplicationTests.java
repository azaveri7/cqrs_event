package com.techbank.accountcmd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountCmdApplicationTests {

	@Test
	void contextLoads() {
	}

}
