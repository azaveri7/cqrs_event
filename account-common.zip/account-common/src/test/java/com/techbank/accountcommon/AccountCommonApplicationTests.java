package com.techbank.accountcommon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
