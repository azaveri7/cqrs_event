package com.techbank.accountcommon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountCommonApplication.class, args);
	}

}
