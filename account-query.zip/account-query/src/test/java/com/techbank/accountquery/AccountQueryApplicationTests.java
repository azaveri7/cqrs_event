package com.techbank.accountquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
